package persistence;

public abstract class Persistence {
	abstract void persist();
}
