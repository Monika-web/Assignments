package dessertItem;

public abstract class DessertItem {
	abstract void getCost();
}
