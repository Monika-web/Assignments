package Shapes;

public abstract class Shape {
	abstract void draw();
}
